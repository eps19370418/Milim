# ミリーム 初版配布セット

初版配布版（2026年11月17日更新）

旧約聖書のヘブライ語原典を読み始めるための教材です。頻出語を『ミリーム440』で覚え、文法を『レーア・ミリーム』で確認し、ルツ記講読に必要な語彙と語形を『ルツ記のミリーム72』で学びます。

## 収録ファイル

| 教材 | PDF | Markdown | JSON |
| --- | --- | --- | --- |
| ミリーム440 | [語彙集](Milim440/Milim440.pdf) | [語彙一覧](Milim440/Milim440.md) | [440語のデータ](Milim440/Milim440.json) |
| ルツ記のミリーム72 | [語彙集](Milim_Ruth/Milim_Ruth_72.pdf)・[ドリル語形集](Milim_Ruth/Milim_Ruth_Drill_Forms.pdf) | [語彙一覧](Milim_Ruth/Milim_Ruth_72.md) | [72語のデータ](Milim_Ruth/Milim_Ruth_72.json)・[ドリル用データ](Milim_Ruth/Milim_Ruth_Drill_AI.json) |
| レーア・ミリーム | [文法書](Rea_Milim/Rea_Milim.pdf) | [文法本文と付録](Rea_Milim/Rea_Milim.md) | [文法と例文のデータ](Rea_Milim/Rea_Milim_AI.json) |

## AIを使う場合

このZIPをAIに渡し、学習・講読・出題・校閲のうち希望する作業を伝えてください。最初に読む指示書は [Milim_Distribution_AI.json（1.1.3）](Milim_Distribution_AI.json) です。ZIPを展開できない場合は、指示書と必要な教材ファイルを個別に渡してください。

Geminiを使って継続学習する場合は、[NotebookLM](https://notebooklm.google.com/) も使えます。ZIPを展開して使用する教材のMarkdownをソースに追加し、必要に応じてPDFも追加してください。学習済みの§や語彙番号、希望する作業は入力欄で伝えます。

巻別教材の制作を依頼する場合は [Milim_Workflow_AI.json](Milim_Workflow_AI.json) を使います。

## 版と収録データ

- レーア・ミリームのPDFは表紙を含めて162ページです。付録6〜8とあとがきはPDFでご覧ください。MarkdownとJSONは従来の組版用原稿に基づき、付録1の608項目を収録しています。配色はPDFで確認でき、区分値はJSONに収録しています。
- ミリーム440のMarkdownとJSONは既存の語彙データから作成しました。JSON中のBDB照合用の日本語下訳には未確認のものが含まれます。
- ルツ記はOpen Scriptures Hebrew Bible（OSHB v2.2）の集計に基づきます。ドリル用JSONには35語の出現データと85節のデータが入っています。補充語形と和訳はドリル語形集PDFも参照してください。

参照データの出典は各教材とAI向け指示書に記載しています。

## 著作権と利用条件

ミリームの著者が権利を有する教材本文・例文・データ・指示書は、出典を明記すれば、商用利用・再配布とも自由です。

出典表記例　『レーア・ミリーム』初版（ミリーム初版配布セット）

第三者の著作物や外部データを利用する場合は、各資料の利用条件に従ってください。
